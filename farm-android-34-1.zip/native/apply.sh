#!/bin/bash
set -e
D=android/app/src/main/java/com/dakahlia/farm
mkdir -p "$D"
cp native/MainActivity.java native/FarmNative.java native/KeepAliveService.java native/BubbleService.java "$D/"
python3 native/patch_manifest.py android/app/src/main/AndroidManifest.xml
R=android/app/src/main/res
if [ -d native/icons ]; then
  for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    mkdir -p "$R/mipmap-$d"
    cp native/icons/mipmap-$d/*.png "$R/mipmap-$d/"
  done
  rm -f $R/mipmap-anydpi-v26/ic_launcher*.xml
  mkdir -p $R/values
  echo '<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#12382A</color></resources>' > $R/values/ic_launcher_background.xml
fi
