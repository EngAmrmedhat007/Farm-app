package com.dakahlia.farm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.view.inputmethod.EditorInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BubbleService extends Service {
    public static boolean running = false;

    static final String[] KEYS = {"h", "f", "w", "t"};
    static final String[] EMO = {"🏠", "🌾", "💧", "🔥"};
    static final String[] NAMES = {"العنابر حسب الساعات", "العلف (السايلو)", "المياه", "الهياتر"};
    int CARD = Color.WHITE;
    int GREEN = Color.parseColor("#1F7A4D");
    int INK = Color.parseColor("#1D2B24");
    int MUTED = Color.parseColor("#6B7A72");
    int LINE = Color.parseColor("#DCE6DF");
    int SOFT = Color.parseColor("#F2F7F4");
    int AMBER = Color.parseColor("#E8A21A");
    int RED = Color.parseColor("#C0392B");

    private void applyTheme() {
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            GREEN = Color.parseColor("#2FA36B"); INK = Color.parseColor("#E8F0EB"); MUTED = Color.parseColor("#93A39A");
            LINE = Color.parseColor("#33443B"); SOFT = Color.parseColor("#223029"); CARD = Color.parseColor("#17211C");
        } else {
            GREEN = Color.parseColor("#1F7A4D"); INK = Color.parseColor("#1D2B24"); MUTED = Color.parseColor("#6B7A72");
            LINE = Color.parseColor("#DCE6DF"); SOFT = Color.parseColor("#F2F7F4"); CARD = Color.WHITE;
        }
    }

    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler hd = new Handler(Looper.getMainLooper());
    private DisplayMetrics dm;

    private LinearLayout rail;
    private WindowManager.LayoutParams railP;
    private boolean expanded = false;

    private View card;
    private WindowManager.LayoutParams cardP;
    private String openKey = null;
    private final Map<String, Map<String, String>> drafts = new HashMap<>();
    private final Map<String, EditText> fields = new HashMap<>();
    private boolean fault = false;
    private boolean twoHeaters = false;

    // ---------- lifecycle ----------
    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (rail != null) return START_STICKY;
        startFg();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        sp = getSharedPreferences("farm_bubble", MODE_PRIVATE);
        dm = getResources().getDisplayMetrics();
        running = true;
        applyTheme();
        buildRail();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (card != null) wm.removeView(card); } catch (Exception e) { }
        try { if (rail != null) wm.removeView(rail); } catch (Exception e) { }
        card = null; rail = null;
        super.onDestroy();
    }

    private void startFg() {
        String ch = "farm_bubble";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(ch, "الفقاعة العائمة", NotificationManager.IMPORTANCE_MIN);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        b.setSmallIcon(getApplicationInfo().icon).setContentTitle("الفقاعة العائمة شغالة").setContentText("اضغط لفتح التطبيق").setContentIntent(pi).setOngoing(true);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, 0x40000000);
            else startForeground(2, n);
        } catch (Exception e) {
            try { startForeground(2, n); } catch (Exception e2) { }
        }
    }

    // ---------- helpers ----------
    private void chain(String... ks) {
        for (int i = 0; i < ks.length; i++) {
            EditText e = fields.get(ks[i]);
            if (e == null) continue;
            e.setSingleLine(true);
            if (i + 1 < ks.length && fields.get(ks[i + 1]) != null) {
                e.setImeOptions(EditorInfo.IME_ACTION_NEXT);
                e.setNextFocusForwardId(fields.get(ks[i + 1]).getId());
            } else e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        }
    }

    private int dp(float v) { return Math.round(v * dm.density); }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable rect(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView tv(String s, float sp_, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp_);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView chip(String s, boolean on, int sizeDp) {
        TextView t = tv(s, 13, on ? Color.WHITE : INK, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(oval(on ? GREEN : SOFT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText field(String hint, boolean decimal) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTextColor(INK);
        e.setHintTextColor(MUTED);
        e.setSingleLine(true);
        e.setInputType(decimal ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL) : InputType.TYPE_CLASS_NUMBER);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(8), 0, dp(8), 0);
        e.setBackground(rect(SOFT, 10, LINE));
        e.setId(View.generateViewId());
        e.setLayoutParams(new LinearLayout.LayoutParams(0, dp(42), 1));
        return e;
    }

    private String shiftDate() {
        Calendar c = Calendar.getInstance();
        if (c.get(Calendar.HOUR_OF_DAY) < 12) c.add(Calendar.DAY_OF_MONTH, -1);
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    private List<String> order() {
        List<String> o = new ArrayList<>();
        String s = sp.getString("order", "h,f,w,t");
        for (String k : s.split(",")) if (k.length() > 0 && idx(k) >= 0 && !o.contains(k)) o.add(k);
        for (String k : KEYS) if (!o.contains(k)) o.add(k);
        return o;
    }

    private boolean hidden(String k) { return ("," + sp.getString("hidden", "") + ",").contains("," + k + ","); }

    private static int idx(String k) { for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(k)) return i; return -1; }

    // ---------- rail (main bubble + tool bubbles) ----------
    private void buildRail() {
        applyTheme();
        if (rail != null) {
            try { wm.removeView(rail); } catch (Exception e) { }
        }
        rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView main = new ImageView(this);
        try { main.setImageDrawable(getPackageManager().getApplicationIcon(getPackageName())); } catch (Exception e) { }
        main.setScaleType(ImageView.ScaleType.CENTER_CROP);
        main.setBackground(oval(GREEN));
        main.setClipToOutline(true);
        main.setElevation(dp(6));
        rail.addView(main, new LinearLayout.LayoutParams(dp(50), dp(50)));
        attachMainTouch(main);

        if (expanded) {
            for (final String k : order()) {
                if (hidden(k)) continue;
                int i = idx(k);
                TextView t = tv(EMO[i], 19, Color.WHITE, false);
                t.setGravity(Gravity.CENTER);
                boolean hasDraft = drafts.containsKey(k);
                t.setBackground(oval(k.equals(openKey) ? GREEN : (hasDraft ? AMBER : Color.parseColor("#33443B"))));
                t.setElevation(dp(4));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
                lp.topMargin = dp(8);
                t.setLayoutParams(lp);
                t.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { toggleCard(k); }
                });
                rail.addView(t);
            }
        }

        boolean first = railP == null;
        if (first) {
            railP = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
            railP.gravity = Gravity.TOP | Gravity.START;
            railP.x = sp.getInt("rx", dm.widthPixels - dp(64));
            railP.y = sp.getInt("ry", dp(220));
        }
        try { wm.addView(rail, railP); } catch (Exception e) { stopSelf(); }
    }

    private void rebuildRail() {
        try { wm.removeView(rail); } catch (Exception e) { }
        buildRail();
    }

    private void attachMainTouch(View v) {
        final float[] st = new float[4];
        final boolean[] moved = {false};
        final boolean[] longDone = {false};
        final Runnable lp = new Runnable() {
            @Override public void run() { if (!moved[0]) { longDone[0] = true; showSettings(); } }
        };
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        st[0] = e.getRawX(); st[1] = e.getRawY(); st[2] = railP.x; st[3] = railP.y;
                        moved[0] = false; longDone[0] = false;
                        hd.postDelayed(lp, 550);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - st[0], dy = e.getRawY() - st[1];
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) { moved[0] = true; hd.removeCallbacks(lp); }
                        if (moved[0]) {
                            railP.x = clamp((int) (st[2] + dx), 0, dm.widthPixels - dp(50));
                            railP.y = clamp((int) (st[3] + dy), 0, dm.heightPixels - dp(60));
                            try { wm.updateViewLayout(rail, railP); } catch (Exception ex) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        hd.removeCallbacks(lp);
                        if (moved[0]) {
                            // snap to nearest side
                            railP.x = railP.x + dp(25) < dm.widthPixels / 2 ? dp(4) : dm.widthPixels - dp(54);
                            sp.edit().putInt("rx", railP.x).putInt("ry", railP.y).apply();
                            try { wm.updateViewLayout(rail, railP); } catch (Exception ex) { }
                        } else if (!longDone[0] && e.getAction() == MotionEvent.ACTION_UP) {
                            expanded = !expanded;
                            if (!expanded) minimizeCard();
                            rebuildRail();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }

    // ---------- card window ----------
    private void toggleCard(String k) {
        if (k.equals(openKey)) { minimizeCard(); rebuildRail(); return; }
        minimizeCard();
        openCard(k);
        rebuildRail();
    }

    private void saveDraft() {
        if (openKey == null) return;
        Map<String, String> d = new HashMap<>();
        for (Map.Entry<String, EditText> e : fields.entrySet()) d.put(e.getKey(), e.getValue().getText().toString());
        d.put("_fault", fault ? "1" : "0");
        d.put("_two", twoHeaters ? "1" : "0");
        Map<String, String> old = drafts.get(openKey);
        if (old != null) { d.put("_house", old.get("_house")); d.put("_hour", old.get("_hour")); }
        d.put("_house", String.valueOf(curHouse));
        d.put("_hour", String.valueOf(curHour));
        boolean any = false;
        for (Map.Entry<String, String> e : d.entrySet()) if (!e.getKey().startsWith("_") && e.getValue().length() > 0) any = true;
        if (any) drafts.put(openKey, d); else drafts.remove(openKey);
    }

    private void minimizeCard() {
        saveDraft();
        removeCard();
        openKey = null;
    }

    private void closeCardAndDiscard() {
        String k = openKey;
        removeCard();
        openKey = null;
        if (k != null) drafts.remove(k);
        rebuildRail();
    }

    private void removeCard() {
        if (card != null) { try { wm.removeView(card); } catch (Exception e) { } }
        card = null;
        fields.clear();
    }

    private int nextHouse = 0, nextHour = -1;
    static final int REG = Color.parseColor("#2E86DE");

    private String regKey() {
        return "reg:" + shiftDate() + ":" + openKey + ("h".equals(openKey) ? ":" + curHour : "");
    }

    private boolean isReg(int house) {
        return ("," + sp.getString(regKey(), "") + ",").contains("," + house + ",");
    }

    private void markReg(int house) {
        if (isReg(house)) return;
        String c = sp.getString(regKey(), "");
        sp.edit().putString(regKey(), c.length() == 0 ? String.valueOf(house) : c + "," + house).apply();
    }

    private int curHouse = 1;
    private int curHour = 20;
    private TextView hourTv;
    private LinearLayout chipRow;
    private TextView preview;
    private TextView saveBtn;

    private void openCard(String k) {
        applyTheme();
        openKey = k;
        fields.clear();
        fault = false;
        twoHeaters = false;
        Map<String, String> d = drafts.get(k);
        curHouse = nextHouse > 0 ? nextHouse : 1;
        curHour = nextHour >= 0 ? nextHour : currentEveHour();
        nextHouse = 0; nextHour = -1;
        if (d != null) {
            try { curHouse = Integer.parseInt(d.get("_house")); curHour = Integer.parseInt(d.get("_hour")); } catch (Exception e) { }
            fault = "1".equals(d.get("_fault"));
            twoHeaters = "1".equals(d.get("_two"));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rect(CARD, 18, LINE));
        root.setElevation(dp(10));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // header (drag handle)
        LinearLayout hdr = new LinearLayout(this);
        hdr.setOrientation(LinearLayout.HORIZONTAL);
        hdr.setGravity(Gravity.CENTER_VERTICAL);
        hdr.setPadding(dp(14), dp(8), dp(8), dp(8));
        GradientDrawable hb = new GradientDrawable();
        hb.setColor(GREEN);
        float r = dp(18);
        hb.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        hdr.setBackground(hb);
        TextView title = tv(EMO[idx(k)] + "  " + NAMES[idx(k)], 14, Color.WHITE, true);
        hdr.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView mn = tv("➖", 15, Color.WHITE, false);
        mn.setGravity(Gravity.CENTER);
        mn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { minimizeCard(); rebuildRail(); } });
        hdr.addView(mn, new LinearLayout.LayoutParams(dp(36), dp(32)));
        TextView cl = tv("✕", 16, Color.WHITE, true);
        cl.setGravity(Gravity.CENTER);
        cl.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeCardAndDiscard(); } });
        hdr.addView(cl, new LinearLayout.LayoutParams(dp(36), dp(32)));
        root.addView(hdr);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12), dp(10), dp(12), dp(12));

        // house chips
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(chipRow);
        body.addView(hs);
        drawChips();

        if (k.equals("h")) buildHouses(body, d);
        else if (k.equals("t")) buildHeater(body, d);
        else buildSingle(body, d, k.equals("f") ? "السايلو (كجم)" : "قراءة المياه");

        saveBtn = tv("", 15, Color.WHITE, true);
        saveBtn.setGravity(Gravity.CENTER);
        saveBtn.setBackground(rect(GREEN, 12, 0));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        sl.topMargin = dp(10);
        body.addView(saveBtn, sl);
        updateSaveLabel();
        saveBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { doSave(); } });

        ScrollView sv = new ScrollView(this);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int w = Math.min(dp(330), dm.widthPixels - dp(20));
        cardP = new WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        cardP.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        cardP.gravity = Gravity.TOP | Gravity.START;
        cardP.x = sp.getInt("cx", (dm.widthPixels - w) / 2);
        cardP.y = sp.getInt("cy", dp(70));
        card = root;
        attachCardDrag(hdr);
        try { wm.addView(card, cardP); } catch (Exception e) { card = null; openKey = null; }
    }

    private void attachCardDrag(View h) {
        final float[] st = new float[4];
        h.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (card == null) return false;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        st[0] = e.getRawX(); st[1] = e.getRawY(); st[2] = cardP.x; st[3] = cardP.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        cardP.x = clamp((int) (st[2] + e.getRawX() - st[0]), -dp(40), dm.widthPixels - dp(60));
                        cardP.y = clamp((int) (st[3] + e.getRawY() - st[1]), 0, dm.heightPixels - dp(120));
                        try { wm.updateViewLayout(card, cardP); } catch (Exception ex) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        sp.edit().putInt("cx", cardP.x).putInt("cy", cardP.y).apply();
                        return true;
                }
                return false;
            }
        });
    }

    private int currentEveHour() { return Calendar.getInstance().get(Calendar.HOUR_OF_DAY); }

    private void drawChips() {
        chipRow.removeAllViews();
        for (int i = 1; i <= 8; i++) {
            final int n = i;
            TextView c = chip(String.valueOf(i), i == curHouse, 34);
            if (isReg(i)) {
                GradientDrawable g = oval(i == curHouse ? GREEN : REG);
                if (i == curHouse) g.setStroke(dp(3), REG);
                c.setBackground(g);
                c.setTextColor(Color.WHITE);
                c.setText(i + "✓");
                c.setTextSize(12);
            }
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { curHouse = n; drawChips(); updateSaveLabel(); }
            });
            chipRow.addView(c);
        }
    }

    private void updateSaveLabel() {
        if (saveBtn == null) return;
        saveBtn.setText(openKey != null && openKey.equals("h") ? "حفظ ← عنبر " + (curHouse % 8 + 1) : "حفظ عنبر " + curHouse);
    }

    private String dv(Map<String, String> d, String k) { return d == null || d.get(k) == null ? "" : d.get(k); }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        r.setLayoutParams(lp);
        return r;
    }

    private EditText add(LinearLayout row, String key, String hint, boolean decimal, Map<String, String> d) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        cl.setMargins(dp(3), 0, dp(3), 0);
        col.setLayoutParams(cl);
        TextView lb = tv(hint, 11, MUTED, true);
        lb.setPadding(dp(4), 0, dp(4), dp(2));
        col.addView(lb);
        EditText e = field("", decimal);
        e.setId(View.generateViewId());
        e.setText(dv(d, key));
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        fields.put(key, e);
        col.addView(e);
        row.addView(col);
        return e;
    }

    private void buildHouses(LinearLayout body, Map<String, String> d) {
        LinearLayout hr = row();
        TextView prev = tv("◀", 16, GREEN, true);
        prev.setGravity(Gravity.CENTER);
        prev.setBackground(rect(SOFT, 10, 0));
        hourTv = tv("", 15, INK, true);
        hourTv.setGravity(Gravity.CENTER);
        TextView next = tv("▶", 16, GREEN, true);
        next.setGravity(Gravity.CENTER);
        next.setBackground(rect(SOFT, 10, 0));
        prev.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { curHour = (curHour + 23) % 24; showHour(); } });
        next.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { curHour = (curHour + 1) % 24; showHour(); } });
        hr.addView(prev, new LinearLayout.LayoutParams(dp(44), dp(38)));
        hr.addView(hourTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        hr.addView(next, new LinearLayout.LayoutParams(dp(44), dp(38)));
        body.addView(hr);
        showHour();

        LinearLayout r1 = row();
        add(r1, "tin", "داخل °", true, d);
        add(r1, "tout", "خارج °", true, d);
        body.addView(r1);
        LinearLayout r2 = row();
        add(r2, "hum", "رطوبة %", true, d);
        add(r2, "fans", "مراوح", false, d);
        body.addView(r2);

        LinearLayout r3 = row();
        EditText note = new EditText(this);
        note.setHint("ملاحظة…");
        note.setTextSize(14);
        note.setTextColor(INK);
        note.setHintTextColor(MUTED);
        note.setSingleLine(true);
        note.setPadding(dp(10), 0, dp(10), 0);
        note.setBackground(rect(SOFT, 10, LINE));
        note.setText(dv(d, "note"));
        note.setId(View.generateViewId());
        fields.put("note", note);
        r3.addView(note, new LinearLayout.LayoutParams(0, dp(42), 1));
        final TextView ft = tv("⚠️ عطل", 13, fault ? Color.WHITE : INK, true);
        ft.setGravity(Gravity.CENTER);
        ft.setBackground(rect(fault ? RED : SOFT, 10, 0));
        ft.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                fault = !fault;
                ft.setTextColor(fault ? Color.WHITE : INK);
                ft.setBackground(rect(fault ? RED : SOFT, 10, 0));
            }
        });
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(dp(72), dp(42));
        fl.setMargins(dp(6), 0, 0, 0);
        r3.addView(ft, fl);
        body.addView(r3);
        chain("tin", "tout", "hum", "fans", "note");
    }

    private void showHour() {
        if (hourTv != null) hourTv.setText("الساعة  " + String.format(java.util.Locale.US, "%02d:00", curHour));
        if (chipRow != null) drawChips();
    }

    private void buildSingle(LinearLayout body, Map<String, String> d, String hint) {
        LinearLayout r = row();
        add(r, "v", hint, true, d);
        body.addView(r);
        chain("v");
    }

    private String durPreview(String v) {
        if (v == null || !v.matches("\\d+")) return "";
        int mm = Integer.parseInt(v.substring(Math.max(0, v.length() - 2)));
        int hh = v.length() > 2 ? Integer.parseInt(v.substring(0, v.length() - 2)) : 0;
        if (mm > 59) return "⚠️ الدقائق أكبر من 59";
        if (hh == 0) return "= " + mm + " دقيقة";
        return "= " + hh + ":" + String.format(java.util.Locale.US, "%02d", mm) + " ساعة";
    }

    private void buildHeater(final LinearLayout body, Map<String, String> d) {
        LinearLayout r1 = row();
        EditText a = add(r1, "h1", "الهيتر 1 (أرقام بس: 215 = 2:15)", false, d);
        body.addView(r1);
        preview = tv("", 13, GREEN, true);
        preview.setGravity(Gravity.CENTER);
        body.addView(preview);
        final LinearLayout r2 = row();
        final EditText b = add(r2, "h2", "الهيتر 2", false, d);
        r2.setVisibility(twoHeaters ? View.VISIBLE : View.GONE);
        final TextView tg = tv(twoHeaters ? "✔ الهيترين مختلفين" : "◻ الهيترين مختلفين", 13, twoHeaters ? GREEN : MUTED, true);
        tg.setPadding(dp(4), dp(8), dp(4), dp(4));
        tg.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                twoHeaters = !twoHeaters;
                tg.setText(twoHeaters ? "✔ الهيترين مختلفين" : "◻ الهيترين مختلفين");
                tg.setTextColor(twoHeaters ? GREEN : MUTED);
                r2.setVisibility(twoHeaters ? View.VISIBLE : View.GONE);
                chain("h1", twoHeaters ? "h2" : "h1");
            }
        });
        body.addView(tg);
        body.addView(r2);
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a1, int b1, int c1) { }
            @Override public void onTextChanged(CharSequence s, int a1, int b1, int c1) { }
            @Override public void afterTextChanged(Editable e) {
                EditText x = fields.get("h1"), y = fields.get("h2");
                String p = durPreview(x == null ? "" : x.getText().toString());
                if (twoHeaters && y != null && y.getText().length() > 0) p += "   |   " + durPreview(y.getText().toString());
                if (preview != null) preview.setText(p);
            }
        };
        a.addTextChangedListener(tw);
        b.addTextChangedListener(tw);
        tw.afterTextChanged(null);
        chain("h1", twoHeaters ? "h2" : "h1");
    }

    private String val(String k) {
        EditText e = fields.get(k);
        return e == null ? "" : e.getText().toString().trim();
    }

    private void doSave() {
        try {
            JSONObject q = new JSONObject();
            q.put("id", System.currentTimeMillis() + "-" + (int) (Math.random() * 9999));
            q.put("date", shiftDate());
            q.put("house", curHouse);
            String k = openKey;
            if (k.equals("h")) {
                q.put("t", "eve");
                q.put("hour", curHour);
                String[] ks = {"tin", "tout", "hum", "fans"};
                boolean any = false;
                for (String f : ks) { String v = val(f); if (v.length() > 0) { q.put(f, v); any = true; } }
                String n = val("note");
                if (n.length() > 0) { q.put("note", n); any = true; }
                if (fault) q.put("fault", true);
                if (!any) { Toast.makeText(this, "اكتب قراءة أو ملاحظة الأول", Toast.LENGTH_SHORT).show(); return; }
            } else if (k.equals("t")) {
                String h1 = val("h1");
                if (h1.length() == 0) { Toast.makeText(this, "اكتب زمن الهيتر", Toast.LENGTH_SHORT).show(); return; }
                q.put("t", "heater");
                q.put("h1", h1);
                if (twoHeaters && val("h2").length() > 0) { q.put("hd", true); q.put("h2", val("h2")); }
            } else {
                String v = val("v");
                if (v.length() == 0) { Toast.makeText(this, "اكتب القيمة الأول", Toast.LENGTH_SHORT).show(); return; }
                q.put("t", k.equals("f") ? "silo" : "water");
                q.put("v", v);
            }
            FarmNative.push(this, q.toString());
            markReg(curHouse);
            Toast.makeText(this, "✔ اتسجل عنبر " + curHouse, Toast.LENGTH_SHORT).show();
            // next house, clear fields
            for (EditText e : fields.values()) e.setText("");
            fault = false;
            drafts.remove(k);
            String ok = openKey;
            nextHouse = curHouse % 8 + 1;
            nextHour = curHour;
            removeCard();
            openCard(ok);
            rebuildRail();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر الحفظ", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- settings card (long-press main bubble) ----------
    private void showSettings() {
        applyTheme();
        minimizeCard();
        rebuildRail();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rect(CARD, 18, LINE));
        root.setElevation(dp(10));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(14), dp(12), dp(14), dp(14));
        root.addView(tv("ترتيب وإظهار الفقاقيع", 15, INK, true));
        root.addView(tv("غيّر الترتيب بالأسهم، والعين للإخفاء", 12, MUTED, false));
        List<String> o = order();
        for (int i = 0; i < o.size(); i++) {
            final String k = o.get(i);
            final int pos = i;
            LinearLayout r = row();
            r.setBackground(rect(SOFT, 10, 0));
            r.setPadding(dp(10), dp(4), dp(6), dp(4));
            TextView nm = tv(EMO[idx(k)] + "  " + NAMES[idx(k)], 13, hidden(k) ? MUTED : INK, true);
            r.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            r.addView(mini("⬆", new View.OnClickListener() { @Override public void onClick(View v) { moveTool(pos, -1); } }));
            r.addView(mini("⬇", new View.OnClickListener() { @Override public void onClick(View v) { moveTool(pos, 1); } }));
            r.addView(mini(hidden(k) ? "🚫" : "👁", new View.OnClickListener() { @Override public void onClick(View v) { toggleHidden(k); } }));
            root.addView(r);
        }
        LinearLayout br = row();
        TextView open = tv("فتح التطبيق", 13, Color.WHITE, true);
        open.setGravity(Gravity.CENTER);
        open.setBackground(rect(GREEN, 10, 0));
        open.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                removeCard();
                Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
            }
        });
        TextView done = tv("تم", 13, INK, true);
        done.setGravity(Gravity.CENTER);
        done.setBackground(rect(SOFT, 10, 0));
        done.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { removeCard(); } });
        TextView stop = tv("إيقاف", 13, Color.WHITE, true);
        stop.setGravity(Gravity.CENTER);
        stop.setBackground(rect(RED, 10, 0));
        stop.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { stopSelf(); } });
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, dp(40), 1);
        b1.setMargins(dp(3), 0, dp(3), 0);
        br.addView(open, b1);
        br.addView(done, new LinearLayout.LayoutParams(b1));
        br.addView(stop, new LinearLayout.LayoutParams(b1));
        root.addView(br);

        int w = Math.min(dp(300), dm.widthPixels - dp(20));
        cardP = new WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        cardP.gravity = Gravity.TOP | Gravity.START;
        cardP.x = (dm.widthPixels - w) / 2;
        cardP.y = dp(120);
        card = root;
        try { wm.addView(card, cardP); } catch (Exception e) { card = null; }
    }

    private TextView mini(String s, View.OnClickListener l) {
        TextView t = tv(s, 15, INK, false);
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(l);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(34)));
        return t;
    }

    private void moveTool(int pos, int d) {
        List<String> o = order();
        int to = pos + d;
        if (to < 0 || to >= o.size()) return;
        String k = o.remove(pos);
        o.add(to, k);
        StringBuilder sb = new StringBuilder();
        for (String x : o) { if (sb.length() > 0) sb.append(','); sb.append(x); }
        sp.edit().putString("order", sb.toString()).apply();
        removeCard();
        rebuildRail();
        showSettings();
    }

    private void toggleHidden(String k) {
        List<String> h = new ArrayList<>();
        for (String x : sp.getString("hidden", "").split(",")) if (x.length() > 0) h.add(x);
        if (h.contains(k)) h.remove(k); else h.add(k);
        StringBuilder sb = new StringBuilder();
        for (String x : h) { if (sb.length() > 0) sb.append(','); sb.append(x); }
        sp.edit().putString("hidden", sb.toString()).apply();
        removeCard();
        rebuildRail();
        showSettings();
    }
}
