package com.dakahlia.farm;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class BubbleService extends Service {
    public static boolean running = false;
    private WindowManager wm;
    private View bubble;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (bubble != null) return START_STICKY;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        TextView t = new TextView(this);
        t.setText("🐔");
        t.setTextSize(26);
        t.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor("#1E6B50"));
        bg.setStroke(4, Color.WHITE);
        t.setBackground(bg);
        bubble = t;

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                150, 150, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 20;
        p.y = 300;

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = p.x; sy = p.y; tx = e.getRawX(); ty = e.getRawY(); moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true;
                        p.x = sx + (int) dx;
                        p.y = sy + (int) dy;
                        wm.updateViewLayout(bubble, p);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            Intent li = getPackageManager().getLaunchIntentForPackage(getPackageName());
                            if (li != null) {
                                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                startActivity(li);
                            }
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, p);
        running = true;
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (bubble != null && wm != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
