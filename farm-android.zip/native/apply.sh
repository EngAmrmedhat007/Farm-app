#!/bin/bash
set -e
D=android/app/src/main/java/com/dakahlia/farm
mkdir -p "$D"
cp native/MainActivity.java native/FarmNative.java native/KeepAliveService.java native/BubbleService.java "$D/"
python3 native/patch_manifest.py android/app/src/main/AndroidManifest.xml
