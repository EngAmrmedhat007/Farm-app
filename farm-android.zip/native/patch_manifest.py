import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
perms = """
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
"""
svc = """
        <service android:name=".KeepAliveService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="farm monitoring" />
        </service>
        <service android:name=".BubbleService" android:exported="false" />
"""
assert '<application' in s and '</application>' in s
s = s.replace('<application', perms + '\n    <application', 1)
s = s.replace('</application>', svc + '    </application>', 1)
open(p, 'w', encoding='utf-8').write(s)
print('manifest patched')
