package com.dakahlia.farm;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "FarmNative")
public class FarmNative extends Plugin {
    static FarmNative inst;
    private static final Object LOCK = new Object();

    @Override
    public void load() { inst = this; }

    static void push(Context c, String json) {
        synchronized (LOCK) {
            SharedPreferences sp = c.getSharedPreferences("farm_quick", Context.MODE_PRIVATE);
            String cur = sp.getString("q", "[]");
            String n = cur.length() <= 2 ? "[" + json + "]" : cur.substring(0, cur.length() - 1) + "," + json + "]";
            sp.edit().putString("q", n).apply();
        }
        try { if (inst != null) inst.notifyListeners("quick", new JSObject()); } catch (Exception e) { }
    }

    // سجل دائم: لا يُمسح عند القراءة؛ التطبيق يتجاهل المكرر بالـid، ويُحذف ما عمره أكثر من 30 يوم
    @PluginMethod
    public void drainQuick(PluginCall call) {
        String out;
        synchronized (LOCK) {
            SharedPreferences sp = getContext().getSharedPreferences("farm_quick", Context.MODE_PRIVATE);
            out = sp.getString("q", "[]");
            try {
                org.json.JSONArray a = new org.json.JSONArray(out), keep = new org.json.JSONArray();
                long lim = System.currentTimeMillis() - 30L * 24 * 3600 * 1000;
                for (int i = 0; i < a.length(); i++) {
                    org.json.JSONObject o = a.getJSONObject(i);
                    String id = o.optString("id", "0-0");
                    long t = 0;
                    try { t = Long.parseLong(id.split("-")[0]); } catch (Exception e) { t = lim + 1; }
                    if (t >= lim) keep.put(o);
                }
                if (keep.length() != a.length()) { out = keep.toString(); sp.edit().putString("q", out).apply(); }
            } catch (Exception e) { }
        }
        JSObject r = new JSObject();
        r.put("items", out);
        call.resolve(r);
    }

    private static WebView printWv;

    @PluginMethod
    public void printHtml(final PluginCall call) {
        final String html = call.getString("html", "");
        final String title = call.getString("title", "تقرير");
        getActivity().runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    WebView w = new WebView(getActivity());
                    printWv = w;
                    w.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView v, String u) {
                            try {
                                PrintManager pm = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                                PrintDocumentAdapter ad = v.createPrintDocumentAdapter(title);
                                pm.print(title, ad, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                                call.resolve();
                            } catch (Exception e) { call.reject("print failed"); }
                        }
                    });
                    w.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null);
                } catch (Exception e) { call.reject("print failed"); }
            }
        });
    }

    @PluginMethod
    public void minimizeApp(PluginCall call) {
        try { getActivity().moveTaskToBack(true); } catch (Exception e) { }
        call.resolve();
    }

    @PluginMethod
    public void bubbleState(PluginCall call) {
        JSObject r = new JSObject();
        r.put("shown", BubbleService.running);
        r.put("overlay", Settings.canDrawOverlays(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void ensureBubble(PluginCall call) {
        Context c = getContext();
        if (Settings.canDrawOverlays(c) && !BubbleService.running)
            ContextCompat.startForegroundService(c, new Intent(c, BubbleService.class));
        call.resolve();
    }

    @PluginMethod
    public void startKeepAlive(PluginCall call) {
        Context c = getContext();
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        ContextCompat.startForegroundService(c, new Intent(c, KeepAliveService.class));
        call.resolve();
    }

    @PluginMethod
    public void stopKeepAlive(PluginCall call) {
        Context c = getContext();
        c.stopService(new Intent(c, KeepAliveService.class));
        call.resolve();
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        Context c = getContext();
        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void requestOverlay(PluginCall call) {
        Context c = getContext();
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void toggleBubble(PluginCall call) {
        Context c = getContext();
        if (!Settings.canDrawOverlays(c)) {
            call.reject("overlay permission missing");
            return;
        }
        boolean shown;
        if (BubbleService.running) {
            c.stopService(new Intent(c, BubbleService.class));
            shown = false;
        } else {
            ContextCompat.startForegroundService(c, new Intent(c, BubbleService.class));
            shown = true;
        }
        JSObject r = new JSObject();
        r.put("shown", shown);
        call.resolve(r);
    }
}
