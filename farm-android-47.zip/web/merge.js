/* منطق الدمج الآمن (إضافة فقط). لا يحذف بيانات أبدًا.
   القاعدة: المزامنة دمج فقط، ولا جهاز يقدر يمسح بيانات جهاز تاني. */
(function (root, f) { if (typeof module === 'object' && module.exports) module.exports = f(); else root.FarmMerge = f(); })(this, function () {
  const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
  const canon = v => {
    if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
    if (isObj(v)) return '{' + Object.keys(v).sort().filter(k => v[k] !== undefined).map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
    const s = JSON.stringify(v); return s === undefined ? 'null' : s;
  };
  const isEmpty = v => v === undefined || v === null || v === '';
  const idArr = a => Array.isArray(a) && (a.length === 0 || a.every(x => isObj(x) && x.id !== undefined && x.id !== null));
  const seg = (p, k) => p + '/' + k;

  /* ctx: { edited:{path:ts} محلي غير مرفوع, cm:{path:ts} ميتا السحابة, rm:{} الناتج, conf:[] , shard, now } */
  function mergeNode(l, c, p, ctx) {
    if (l === undefined) return c;
    if (c === undefined) return l;
    if (isObj(l) && isObj(c)) {
      const o = {};
      Object.keys(l).forEach(k => { o[k] = mergeNode(l[k], c[k], seg(p, k), ctx); });
      Object.keys(c).forEach(k => { if (!(k in o)) o[k] = c[k]; });
      return o;
    }
    if (Array.isArray(l) && Array.isArray(c) && idArr(l) && idArr(c) && (l.length || c.length)) {
      const out = [], pos = {};
      l.forEach(x => { pos[String(x.id)] = out.length; out.push(x); });
      c.forEach(x => {
        const k = String(x.id);
        if (k in pos) out[pos[k]] = mergeNode(out[pos[k]], x, seg(p, '#' + k), ctx);
        else { pos[k] = out.length; out.push(x); }
      });
      if (out.every(x => typeof x.id === 'number')) out.sort((a, b) => a.id - b.id);
      return out;
    }
    /* ورقة: قيمتان مختلفتان */
    if (canon(l) === canon(c)) return l;
    const ed = ctx.edited[p] || (ctx.seed ? 1 : 0), tc = ctx.cm[p] || 0;
    if (!ed) { ctx.rm[p] = tc; return c; }               // الجهاز ما عدّلش: السحابة تفوز
    const tl = ed;
    let win;
    if (isEmpty(c) && !isEmpty(l)) { win = 'l'; }
    else if (isEmpty(l) && !isEmpty(c)) { win = tl > tc ? 'l' : 'c'; }
    else if (tl === 1 && tc === 0) { win = 'c'; }         // أول ربط: بيانات قديمة الاتنين، السحابة هي المشتركة
    else { win = tl >= tc ? 'l' : 'c'; }
    if (!isEmpty(l) && !isEmpty(c) && (tc > 0 || tl === 1) && !(ctx.shard === 'settings' && tl === 1)) ctx.conf.push({ shard: ctx.shard, path: p, local: l, cloud: c, win: win });
    if (win === 'l') { ctx.rm[p] = tl; return l; }
    ctx.rm[p] = tc; return c;
  }
  /* يرجع { obj, meta, conf } */
  function mergeShard(shard, local, cloud, edited, cloudMeta, seed) {
    const ctx = { edited: edited || {}, cm: cloudMeta || {}, rm: {}, conf: [], shard: shard, seed: !!seed };
    const obj = mergeNode(local === undefined ? {} : local, cloud === undefined ? {} : cloud, '', ctx);
    const meta = Object.assign({}, ctx.cm, ctx.rm);
    return { obj: obj, meta: meta, conf: ctx.conf };
  }
  /* يسجل التعديلات المحلية (فرق قديم/جديد) في edited بوقت now. لا يسجل حذف. */
  function touch(oldv, newv, p, edited, now) {
    if (newv === undefined) return;
    if (isObj(newv) && isObj(oldv || {})) { Object.keys(newv).forEach(k => touch(oldv ? oldv[k] : undefined, newv[k], seg(p, k), edited, now)); return; }
    if (Array.isArray(newv) && idArr(newv) && newv.length && (oldv === undefined || (Array.isArray(oldv) && idArr(oldv)))) {
      const om = {}; (oldv || []).forEach(x => om[String(x.id)] = x);
      newv.forEach(x => touch(om[String(x.id)], x, seg(p, '#' + x.id), edited, now)); return;
    }
    if (oldv === undefined || canon(oldv) !== canon(newv)) edited[p] = now;
  }
  /* قيمة عند مسار (للتعارضات) */
  function setAt(root, p, v) {
    const parts = p.split('/').slice(1);
    let cur = root;
    for (let i = 0; i < parts.length - 1; i++) {
      const s = parts[i];
      if (Array.isArray(cur) && s[0] === '#') { cur = cur.find(x => String(x.id) === s.slice(1)); }
      else { if (cur[s] === undefined) cur[s] = {}; cur = cur[s]; }
      if (!cur) return false;
    }
    const last = parts[parts.length - 1];
    if (Array.isArray(cur) && last[0] === '#') return false;
    cur[last] = v; return true;
  }
  return { mergeShard, touch, setAt, canon, mergeNode };
});
