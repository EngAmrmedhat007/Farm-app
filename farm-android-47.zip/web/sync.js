/* مزامنة Firebase: تسجيل الدخول + حفظ البيانات على السحابة.
   التطبيق يفضل شغال من التخزين المحلي حتى من غير نت، والمزامنة بتتم في الخلفية. */
const CFG = {
  apiKey: "AIzaSyB6bFSV5oOF2jUcY0r-F1P5GbOyVmEFsWw",
  authDomain: "minya-farm-3-007.firebaseapp.com",
  projectId: "minya-farm-3-007",
  storageBucket: "minya-farm-3-007.firebasestorage.app",
  messagingSenderId: "608361914612",
  appId: "1:608361914612:web:9b74551d2fb7abca1bfea1"
};
const B = 'https://www.gstatic.com/firebasejs/10.14.1/';
const COL = 'farm';
const OBJK = ['days', 'eve', 'todo', 'feedEng', 'feedCrew', 'crewMod', 'evx', 'copied', 'handover']; // كلها مفاتيحها تبدأ بتاريخ
const LISTK = ['treat', 'alerts', 'issues', 'pharm'];
const LOCAL_SET = ['pin', 'pinQ', 'pinA', 'lastBackup', 'sound', 'wake']; // إعدادات خاصة بكل جهاز (و fired كمان محلي)
const LSK = 'farm_sync_v1', BKK = 'farm_prelink_backup_v1';

/* ---------- أدوات ---------- */
const canon = v => {
  if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().filter(k => v[k] !== undefined).map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
  const s = JSON.stringify(v); return s === undefined ? 'null' : s;
};
const dateOf = k => (String(k).match(/^\d{4}-\d{2}-\d{2}/) || ['_'])[0];
function buildObj(S) {
  const out = {};
  for (const k of OBJK) {
    const o = S[k] || {};
    for (const key of Object.keys(o)) {
      const id = 'd_' + dateOf(key);
      const sh = out[id] || (out[id] = {});
      (sh[k] || (sh[k] = {}))[key] = o[key];
    }
  }
  const set = {}; for (const k in S.settings) if (!LOCAL_SET.includes(k)) set[k] = S.settings[k];
  out.settings = set;
  const l = {}; LISTK.forEach(k => l[k] = S[k] || []); out.lists = l;
  return out;
}
function build(S) { const o = buildObj(S), sig = {}; for (const id in o) sig[id] = canon(o[id]); return sig; }
/* دمج فقط: بيضيف للجهاز ومبيمسحش حاجة منه أبدًا */
function assignShard(S, id, obj) {
  if (id === 'settings') { for (const k in obj) if (!LOCAL_SET.includes(k)) S.settings[k] = obj[k]; return; }
  if (id === 'lists') { LISTK.forEach(k => { if (Array.isArray(obj[k])) S[k] = obj[k]; }); return; }
  for (const k of OBJK) {
    const tgt = S[k] || (S[k] = {});
    const src = obj[k] || {};
    for (const key in src) tgt[key] = src[key];
  }
}
const rd = () => { try { return JSON.parse(localStorage.getItem(LSK)) || {}; } catch (e) { return {}; } };
const wr = o => { try { localStorage.setItem(LSK, JSON.stringify(o)); } catch (e) {} };

/* ---------- واجهة ---------- */
const css = document.createElement('style');
css.textContent = `
#syncPill{position:fixed;z-index:35;bottom:calc(env(safe-area-inset-bottom) + 76px);left:8px;font:600 11px var(--font);padding:3px 9px;border-radius:99px;background:var(--surface);color:var(--muted);border:1px solid var(--line);opacity:.92;cursor:pointer}
#syncPill.ok{color:var(--ok)}#syncPill.sync{color:var(--info)}#syncPill.bad{color:var(--warn)}
#syncLogin{position:fixed;inset:0;z-index:250;background:var(--bg);display:grid;place-items:center;padding:24px;font-family:var(--font);color:var(--fg)}
#syncLogin form,#syncAcc .box{width:min(380px,100%);display:grid;gap:12px;background:var(--surface);border:1px solid var(--line);border-radius:var(--r);padding:22px}
#syncLogin h2,#syncAcc h2{margin:0;font-family:var(--display);font-size:24px;text-align:center}
#syncLogin input{font:inherit;padding:12px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--fg);width:100%;box-sizing:border-box;direction:ltr;text-align:left}
#syncLogin button,#syncAcc button{font:700 16px var(--font);padding:12px;border-radius:12px;border:0;background:var(--brand);color:var(--brand-fg);cursor:pointer}
#syncLogin button.alt,#syncAcc button.alt{background:transparent;color:var(--muted);font-weight:500;font-size:14px}
#syncLogin .err{color:var(--bad);font-size:14px;min-height:18px;text-align:center}
#syncAcc{position:fixed;inset:0;z-index:240;background:rgba(0,0,0,.45);display:grid;place-items:center;padding:24px;font-family:var(--font);color:var(--fg)}
#syncAcc .em{direction:ltr;text-align:center;color:var(--muted);font-size:14px;word-break:break-all}
`;
document.head.appendChild(css);
const pill = document.createElement('div'); pill.id = 'syncPill'; document.body.appendChild(pill);
let state = 'off', user = null, dirty = new Set(), signOutFn = null, openLogin = () => {};
function paint() {
  let t, c = '';
  if (state === 'nosdk') { t = '⚠ بدون مزامنة (لا يوجد اتصال)'; c = 'bad'; }
  else if (!user) { t = '☁ غير مسجّل، اضغط للدخول'; c = 'bad'; }
  else if (!navigator.onLine) { t = '⚠ أوفلاين، محفوظ على الجهاز'; c = 'bad'; }
  else if (state === 'sync' || dirty.size) { t = '↻ جاري المزامنة'; c = 'sync'; }
  else if (state === 'err') { t = '⚠ تعذّرت المزامنة'; c = 'bad'; }
  else { t = '☁ متزامن ✓'; c = 'ok'; }
  let nc = 0; try { nc = (JSON.parse(localStorage.getItem('farm_conflicts_v1')) || []).length; } catch (e) {}
  if (nc) { t += ' · ⚠ ' + nc + ' تعارض'; c = 'bad'; }
  pill.textContent = t; pill.className = c;
}
addEventListener('online', paint); addEventListener('offline', paint);
const errAr = e => {
  const c = (e && e.code) || '';
  if (/invalid-credential|wrong-password|user-not-found|invalid-email/.test(c)) return 'الإيميل أو كلمة السر غلط';
  if (/network/.test(c)) return 'مفيش اتصال بالإنترنت';
  if (/too-many/.test(c)) return 'محاولات كتير، استنى شوية وجرّب تاني';
  if (/user-disabled/.test(c)) return 'الحساب ده متوقف';
  return 'تعذّر تسجيل الدخول (' + (c || 'خطأ') + ')';
};

/* ---------- التشغيل ---------- */
(async function () {
  const F = window.FARM;
  if (!F) return;
  const store = rd();
  store.edited = store.edited || {}; store.linkedShards = store.linkedShards || {};
  dirty = new Set(store.dirty || []);
  const FM = window.FarmMerge;
  const clone = o => JSON.parse(JSON.stringify(o));
  const sigsOf = o => { const r = {}; for (const id in o) r[id] = canon(o[id]); return r; };
  let curO = clone(buildObj(F.get())), cur = sigsOf(curO), sent = Object.assign({}, cur);
  for (const id of [...dirty]) if (!(id in cur)) dirty.delete(id);
  const save = () => { store.dirty = [...dirty]; wr(store); };
  const CK = 'farm_conflicts_v1', PB = 'farm_presync_backup_v2';
  const getConf = () => { try { return JSON.parse(localStorage.getItem(CK)) || []; } catch (e) { return []; } };
  const setConf = a => { try { localStorage.setItem(CK, JSON.stringify(a.slice(-200))); } catch (e) {} paint(); };
  window.__farmConf = getConf;
  let lastBk = 0;
  function backupNow() {
    if (Date.now() - lastBk < 600000) return; lastBk = Date.now();
    try { localStorage.setItem(PB, JSON.stringify({ at: Date.now(), data: F.get() })); } catch (e) {}
  }
  function logConf(list) {
    if (!list.length) return;
    const a = getConf(), seen = new Set(a.map(x => x.shard + x.path + canon(x.other)));
    list.forEach(c => {
      const kept = c.win === 'l' ? c.local : c.cloud, other = c.win === 'l' ? c.cloud : c.local;
      const key = c.shard + c.path + canon(other);
      if (!seen.has(key)) { seen.add(key); a.push({ shard: c.shard, path: c.path, kept: kept, other: other, at: Date.now() }); }
    });
    setConf(a);
  }

  /* تتبع التعديلات المحلية بوقت كل خانة */
  function track() {
    const n = buildObj(F.get()), now = Date.now();
    for (const id in n) {
      const sig = canon(n[id]);
      if (sig !== cur[id]) {
        FM.touch(curO[id], n[id], '', (store.edited[id] = store.edited[id] || {}), now);
        dirty.add(id);
      }
    }
    curO = clone(n); cur = sigsOf(n); save(); paint();
  }

  let M;
  try {
    M = await Promise.all([import(B + 'firebase-app.js'), import(B + 'firebase-auth.js'), import(B + 'firebase-firestore.js')]);
  } catch (e) { state = 'nosdk'; paint(); F.onSave = track; return; }
  const [A, AU, FS] = M;
  const app = A.initializeApp(CFG);
  const auth = AU.getAuth(app);
  let db;
  try { db = FS.initializeFirestore(app, { localCache: FS.persistentLocalCache({ tabManager: FS.persistentMultipleTabManager() }) }); }
  catch (e) { db = FS.getFirestore(app); }

  let ready = false, unsub = null, timer = null, retry = null;
  const busy = new Set();

  F.onSave = () => { track(); clearTimeout(timer); timer = setTimeout(flush, 1200); };

  const parseDoc = d => {
    let obj = {}, meta = {};
    try { obj = JSON.parse(d.json) || {}; } catch (e) { return null; }
    try { meta = d.meta ? JSON.parse(d.meta) : {}; } catch (e) {}
    return { obj: obj, meta: meta };
  };

  /* يطبّق ناتج الدمج على الجهاز: إضافة فقط */
  function absorb(id, r, startTs, cloudSig) {
    const S = F.get(), localNow = buildObj(S)[id] || {};
    const r2 = FM.mergeShard(id, localNow, r.obj, store.edited[id] || {}, r.meta, false);
    const before = cur[id] === undefined ? '{}' : cur[id];
    let changed = false;
    if (canon(r2.obj) !== before) { backupNow(); assignShard(S, id, r2.obj); changed = true; }
    logConf(r.conf);
    if (startTs) { const e = store.edited[id] || {}; for (const p in e) if (e[p] <= startTs) delete e[p]; }
    store.linkedShards[id] = 1;
    if (changed) { F.refresh(); }
    curO = clone(buildObj(F.get())); cur = sigsOf(curO);
    sent[id] = cloudSig;
    if ((cur[id] === undefined ? '{}' : cur[id]) === cloudSig) dirty.delete(id); else dirty.add(id);
    save(); paint();
    return changed;
  }

  async function push(id) {
    if (busy.has(id)) return; busy.add(id);
    const startTs = Date.now(), edSnap = Object.assign({}, store.edited[id] || {}), localObj = curO[id] || {}, seed = !store.linkedShards[id];
    try {
      const ref = FS.doc(db, COL, id);
      const res = await FS.runTransaction(db, async tx => {
        const snap = await tx.get(ref);
        let cloud = { obj: {}, meta: {} }, cJson = '{}';
        if (snap.exists()) { const d = snap.data(); const p = parseDoc(d); if (!p) throw new Error('cloud-bad-json'); cloud = p; cJson = canon(p.obj); }
        const r = FM.mergeShard(id, localObj, cloud.obj, edSnap, cloud.meta, seed);
        const mj = canon(r.obj), same = mj === cJson && canon(r.meta) === canon(cloud.meta);
        if (!same) tx.set(ref, { json: mj, meta: JSON.stringify(r.meta), v: 2, by: user.email || user.uid, ts: FS.serverTimestamp() });
        return { r: r, sig: mj };
      });
      absorb(id, res.r, startTs, res.sig);
      state = 'ok';
    } catch (e) { console.warn('sync write failed', id, e); state = 'err'; clearTimeout(retry); retry = setTimeout(flush, 30000); }
    busy.delete(id); paint();
    if (dirty.size && state === 'ok') flush();
  }

  function flush() {
    if (!ready || !user) return;
    for (const id of [...dirty]) push(id);
    paint();
  }
  addEventListener('online', () => { if (ready) flush(); });

  /* استلام من السحابة: دمج، مش استبدال */
  function mergeIn(id, d) {
    const p = parseDoc(d); if (!p) return false;
    const sigC = canon(p.obj);
    if (!dirty.has(id) && cur[id] === sigC) { sent[id] = sigC; return false; }
    const r = FM.mergeShard(id, curO[id] || {}, p.obj, store.edited[id] || {}, p.meta, !store.linkedShards[id]);
    return absorb(id, r, 0, sigC);
  }

  function reconcile(snap) {
    const S = F.get();
    const cloud = {}; snap.forEach(d => { cloud[d.id] = d.data(); });
    if (!store.linked && Object.keys(cloud).length && Object.keys(S.days || {}).length) {
      try { localStorage.setItem(BKK, JSON.stringify(S)); } catch (e) {}
    }
    for (const id in cloud) mergeIn(id, cloud[id]);
    for (const id in cur) if (!(id in cloud)) dirty.add(id);   // موجود محليًا بس: ارفعه
    store.linked = true; save();
    ready = true; state = 'ok'; paint(); flush();
  }

  function listen() {
    state = 'sync'; paint();
    unsub = FS.onSnapshot(FS.collection(db, COL), { includeMetadataChanges: true }, snap => {
      if (!ready) { if (!snap.metadata.fromCache) reconcile(snap); return; }
      snap.docChanges().forEach(ch => {
        if (ch.type === 'removed' || ch.doc.metadata.hasPendingWrites) return;   // الحذف من السحابة مبيتطبقش على الجهاز
        mergeIn(ch.doc.id, ch.doc.data());
      });
      if (dirty.size) { clearTimeout(timer); timer = setTimeout(flush, 800); }
      paint();
    }, e => { console.warn('sync listen failed', e); state = 'err'; paint(); });
  }

  function stop() { if (unsub) unsub(); unsub = null; ready = false; }

  /* شاشة الدخول */
  function showLogin() {
    if (document.getElementById('syncLogin')) return;
    const el = document.createElement('div'); el.id = 'syncLogin';
    el.innerHTML = '<form><h2>🌿 متابعة المزرعة</h2><div class="small" style="text-align:center;color:var(--muted)">سجّل دخولك عشان البيانات تتحفظ وتظهر على كل الأجهزة</div>' +
      '<input type="email" id="sEm" placeholder="الإيميل" autocomplete="username" required><input type="password" id="sPw" placeholder="كلمة السر" autocomplete="current-password" required>' +
      '<div class="err" id="sErr"></div><button type="submit">دخول</button><button type="button" class="alt" id="sSkip">متابعة بدون مزامنة</button></form>';
    document.body.appendChild(el);
    el.querySelector('form').addEventListener('submit', async ev => {
      ev.preventDefault();
      const b = el.querySelector('button[type=submit]'), er = el.querySelector('#sErr');
      b.disabled = true; b.textContent = 'جاري الدخول...'; er.textContent = '';
      try { await AU.signInWithEmailAndPassword(auth, el.querySelector('#sEm').value.trim(), el.querySelector('#sPw').value); }
      catch (e) { er.textContent = errAr(e); b.disabled = false; b.textContent = 'دخول'; }
    });
    el.querySelector('#sSkip').addEventListener('click', () => el.remove());
    setTimeout(() => { const i = el.querySelector('#sEm'); if (i) i.focus(); }, 60);
  }
  openLogin = showLogin;
  const hideLogin = () => { const e = document.getElementById('syncLogin'); if (e) e.remove(); };

  function showAcc() {
    const el = document.createElement('div'); el.id = 'syncAcc';
    const list = getConf();
    const fmt = v => typeof v === 'string' ? (v === '' ? '(فاضي)' : v) : JSON.stringify(v);
    const lab = c => c.path.split('/').slice(1).map(x => x.replace(/^#/, '')).join(' › ');
    el.innerHTML = '<div class="box" style="max-height:88vh;overflow:auto"><h2>الحساب</h2><div class="em"></div>' +
      (list.length ? '<div class="small" style="color:var(--warn);text-align:center">تسجيلين اتعارضوا. الاتنين متحفظين، اختار اللي يفضل:</div>' +
        list.map((c, i) => '<div class="cf" data-i="' + i + '" style="border:1px solid var(--line);border-radius:12px;padding:10px;display:grid;gap:6px"><div class="small" style="direction:ltr;text-align:left;word-break:break-all;color:var(--muted)"></div>' +
          '<button data-k="kept" class="alt" style="border:1px solid var(--line)">سيبها: <b class="kv1"></b></button><button data-k="other" class="alt" style="border:1px solid var(--line)">غيّرها لـ: <b class="kv2"></b></button></div>').join('') : '') +
      '<button class="alt" id="aClose">إغلاق</button><button id="aOut" style="background:var(--bad);color:#fff">تسجيل الخروج</button></div>';
    el.querySelector('.em').textContent = user.email || '';
    el.querySelectorAll('.cf').forEach(d => { const c = list[+d.dataset.i]; d.firstChild.textContent = lab(c); d.querySelector('.kv1').textContent = fmt(c.kept); d.querySelector('.kv2').textContent = fmt(c.other); });
    el.addEventListener('click', e => {
      if (e.target === el || e.target.id === 'aClose') { el.remove(); return; }
      const b = e.target.closest('button[data-k]'); if (!b) return;
      const d = b.closest('.cf'), i = +d.dataset.i, c = list[i], all = getConf();
      const idx = all.findIndex(x => x.shard === c.shard && x.path === c.path && canon(x.other) === canon(c.other));
      if (b.dataset.k === 'other') {
        const S = F.get(); FM.setAt(c.shard === 'settings' ? S.settings : S, c.path, c.other);
        F.refresh(); F.onSave();
      }
      if (idx >= 0) all.splice(idx, 1); setConf(all); el.remove(); if (all.length) showAcc();
    });
    el.querySelector('#aOut').addEventListener('click', async () => { el.remove(); try { await AU.signOut(auth); } catch (e) {} });
    document.body.appendChild(el);
  }
  pill.addEventListener('click', () => { if (user) showAcc(); else showLogin(); });

  AU.onAuthStateChanged(auth, u => {
    user = u || null;
    if (user) { hideLogin(); stop(); listen(); }
    else { stop(); state = 'off'; paint(); showLogin(); }
    paint();
  });
  paint();
})();
