const M=require(process.env.HOME+'/farm/v45/web/merge.js');
let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FAIL',n))};
const cloud={days:{'2026-11-27':{'1c':{c1:'10',feed:'50'}}}};
// 1 empty device must not wipe
let r=M.mergeShard('d_x',{},cloud,{},{});
T('empty keeps cloud',M.canon(r.obj)===M.canon(cloud));
// 2 cloud empty, local has data -> union
r=M.mergeShard('d_x',cloud,{},{},{});T('local kept',M.canon(r.obj)===M.canon(cloud));
// 3 different fields merge
r=M.mergeShard('d_x',{days:{'2026-11-27':{'1c':{c1:'10',feed:'50',dead:'2'}}}},{days:{'2026-11-27':{'1c':{c1:'10',feed:'50',broken:'1'}}}},{},{});
T('fields union',r.obj.days['2026-11-27']['1c'].dead==='2'&&r.obj.days['2026-11-27']['1c'].broken==='1');
// 4 stale device not edited: cloud newer wins
r=M.mergeShard('d_x',{days:{a:{k:{f:'5'}}}},{days:{a:{k:{f:'6'}}}},{},{'/days/a/k/f':900});
T('stale takes cloud',r.obj.days.a.k.f==='6');
// 5 both edited, local newer
r=M.mergeShard('d_x',{days:{a:{k:{f:'7'}}}},{days:{a:{k:{f:'6'}}}},{'/days/a/k/f':1000},{'/days/a/k/f':900});
T('newer local wins',r.obj.days.a.k.f==='7'&&r.conf.length===1&&r.conf[0].cloud==='6');
// 6 both edited, cloud newer, local logged as conflict
r=M.mergeShard('d_x',{days:{a:{k:{f:'7'}}}},{days:{a:{k:{f:'6'}}}},{'/days/a/k/f':800},{'/days/a/k/f':900});
T('newer cloud wins',r.obj.days.a.k.f==='6'&&r.conf[0].local==='7');
// 7 id arrays
r=M.mergeShard('lists',{treat:[{id:'a',n:1},{id:'b',n:2}]},{treat:[{id:'a',n:1},{id:'c',n:3}]},{},{});
T('id union',r.obj.treat.length===3);
// 8 touch
const e={};M.touch({days:{a:{k:{f:'5'}}}},{days:{a:{k:{f:'6',g:'1'}}}},'',e,42);
T('touch',e['/days/a/k/f']===42&&e['/days/a/k/g']===42&&Object.keys(e).length===2);
// 9 deliberate clear newer than cloud
r=M.mergeShard('d_x',{days:{a:{k:{f:''}}}},{days:{a:{k:{f:'6'}}}},{'/days/a/k/f':1000},{'/days/a/k/f':900});
T('clear wins if newer',r.obj.days.a.k.f==='');
// 10 numeric id array sort + setAt
r=M.mergeShard('settings',{houses:[{id:2,name:'x'}]},{houses:[{id:1,name:'y'},{id:2,name:'x'}]},{},{});
T('house sort',r.obj.houses[0].id===1&&r.obj.houses.length===2);
const R={treat:[{id:'a',n:1}]};M.setAt(R,'/treat/#a/n',9);T('setAt',R.treat[0].n===9);
console.log('ok',ok,'bad',bad);
