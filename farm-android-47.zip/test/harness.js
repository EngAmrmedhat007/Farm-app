const fs=require('fs'),vm=require('vm'),path=require('path');
const W=process.env.HOME+'/farm/v45/web/';
const FM=require(W+'merge.js');
const src=fs.readFileSync(W+'sync.js','utf8').replace(/import\(B \+ /g,'__imp(B + ');
const dummy=()=>{const f=function(){};return new Proxy(f,{get:(t,k)=>k===Symbol.toPrimitive?()=>'':k==='textContent'||k==='value'?'':dummy(),set:()=>true,apply:()=>dummy()})};
function makeCloud(){const docs={},ls=[];return{docs,ls,
  write(id,d){docs[id]=Object.assign({},d);ls.forEach(l=>l([{id,data:()=>docs[id]}]))}}}
async function device(name,cloud,initS,opts={}){
  const store={};
  const localStorage={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>delete store[k]};
  let S=JSON.parse(JSON.stringify(initS));
  const FARM={get:()=>S,refresh(){S=JSON.parse(JSON.stringify(S))},onSave:null};
  let online=true;
  const user={email:name+'@x'};
  const FSm={
    initializeFirestore:()=>({}),getFirestore:()=>({}),persistentLocalCache:()=>({}),persistentMultipleTabManager:()=>({}),
    doc:(db,c,id)=>({id}),collection:()=>({}),serverTimestamp:()=>1,
    onSnapshot(col,o,cb){const mk=ch=>({metadata:{fromCache:false},forEach:f=>Object.keys(cloud.docs).forEach(id=>f({id,data:()=>cloud.docs[id]})),docChanges:()=>ch.map(c=>({type:'modified',doc:Object.assign({metadata:{hasPendingWrites:false}},c)}))});
      cloud.ls.push(ch=>{if(online)cb(mk(ch))});setTimeout(()=>cb(mk([])),0);return()=>{}},
    async runTransaction(db,fn){if(!online)throw new Error('offline');const writes=[];
      const tx={get:async ref=>({exists:()=>ref.id in cloud.docs,data:()=>cloud.docs[ref.id]}),set:(ref,d)=>writes.push([ref.id,d])};
      const r=await fn(tx);writes.forEach(([id,d])=>cloud.write(id,d));return r}};
  const mods={'firebase-app.js':{initializeApp:()=>({})},'firebase-auth.js':{getAuth:()=>({}),onAuthStateChanged:(a,cb)=>setTimeout(()=>cb(user),0),signInWithEmailAndPassword:async()=>{},signOut:async()=>{}},'firebase-firestore.js':FSm};
  const ctx={window:null,document:dummy(),localStorage,navigator:{onLine:true},console:{log(){},warn(){}},setTimeout,clearTimeout,JSON,Object,Date,Promise,Array,Set,String,Number,Math,Error,
    addEventListener(){},__imp:async u=>mods[u.split('/').pop()],FarmMerge:FM};
  ctx.window=ctx;ctx.FARM=FARM;ctx.window.FARM=FARM;
  vm.createContext(ctx);
  vm.runInContext('(async()=>{'+src.replace(/^const B =/m,'var B =')+'})()',ctx);
  await sleep(50);
  return{S:()=>S,FARM,setOnline:v=>{online=v},edit(fn){fn(S);FARM.onSave()},store,localStorage};
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
module.exports={device,makeCloud,sleep,FM};
