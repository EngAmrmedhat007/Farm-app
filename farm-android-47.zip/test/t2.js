const {device,makeCloud,sleep,FM}=require('./harness.js');
let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FAIL',n))};
const DEF=()=>({settings:{hot:30,houses:[{id:1,name:'عنبر 1'}]},days:{},eve:{},treat:[],alerts:[],issues:[],pharm:[],todo:{},feedEng:{},feedCrew:{},crewMod:{},evx:{},copied:{},handover:{}});
(async()=>{
 const cloud=makeCloud();
 const full=DEF();full.days['2026-11-27']={'1c':{c1:'10',feed:'50'}};full.days['2026-11-26']={'1c':{c1:'9'}};full.settings.hot=33;
 // A has data, links first
 const A=await device('A',cloud,full);await sleep(1500);
 T('cloud has A data',!!cloud.docs['d_2026-11-27'] && JSON.parse(cloud.docs['d_2026-11-27'].json).days['2026-11-27']['1c'].feed==='50');
 const before=JSON.stringify(Object.keys(cloud.docs).sort().map(k=>cloud.docs[k].json));
 // B empty device syncs after: must not wipe
 const B=await device('B',cloud,DEF());await sleep(1500);
 T('B got data',B.S().days['2026-11-27']['1c'].feed==='50');
 T('B got settings',B.S().settings.hot===33);
 T('cloud unchanged by empty B',before===JSON.stringify(Object.keys(cloud.docs).sort().map(k=>cloud.docs[k].json)));
 T('A intact',A.S().days['2026-11-26']['1c'].c1==='9');
 // C empty device that syncs BEFORE data arrives (offline then online)
 // concurrent edits different fields while B offline
 B.setOnline(false);
 B.edit(S=>{S.days['2026-11-27']['1c'].dead='2'});
 A.edit(S=>{S.days['2026-11-27']['1c'].broken='1'});
 await sleep(1500);
 B.setOnline(true);B.FARM.onSave();await sleep(2500);
 const fa=A.S().days['2026-11-27']['1c'],fb=B.S().days['2026-11-27']['1c'];
 T('A has both',fa.dead==='2'&&fa.broken==='1');T('B has both',fb.dead==='2'&&fb.broken==='1');
 // conflict: same field both offline
 A.setOnline(false);B.setOnline(false);
 A.edit(S=>{S.days['2026-11-27']['1c'].feed='55'});await sleep(20);
 B.edit(S=>{S.days['2026-11-27']['1c'].feed='60'});
 A.setOnline(true);A.FARM.onSave();await sleep(1500);
 B.setOnline(true);B.FARM.onSave();await sleep(2500);
 const ca=A.S().days['2026-11-27']['1c'].feed,cb=B.S().days['2026-11-27']['1c'].feed;
 T('converged',ca===cb);
 const confB=JSON.parse(B.localStorage.getItem('farm_conflicts_v1')||'[]'),confA=JSON.parse(A.localStorage.getItem('farm_conflicts_v1')||'[]');
 const vals=[...confA,...confB].map(c=>c.other);
 console.log('feed',ca,'confA',JSON.stringify(confA.map(c=>[c.kept,c.other])),'confB',JSON.stringify(confB.map(c=>[c.kept,c.other])));
 T('conflict logged somewhere with loser value',vals.length>0);
 // never deletes: remove key on A locally, cloud still has it
 A.edit(S=>{delete S.days['2026-11-26']});await sleep(1500);
 T('cloud keeps deleted day',!!JSON.parse(cloud.docs['d_2026-11-26'].json).days);
 // empty-first-link of stale device with extra local-only data pushes it
 const D=DEF();D.days['2026-11-20']={'2c':{c1:'3'}};
 const Dd=await device('D',cloud,D);await sleep(2000);
 T('D local-only pushed',!!cloud.docs['d_2026-11-20']);
 T('D got others',Dd.S().days['2026-11-27']&&A.S().days['2026-11-20']);
 console.log('ok',ok,'bad',bad);process.exit(0);
})();
